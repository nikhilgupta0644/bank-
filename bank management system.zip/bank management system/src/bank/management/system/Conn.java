
package bank.management.system;

import java.sql.*;

public class Conn {
    
    
    Connection c;
    Statement s;

    /**
     *
     */
    public Conn(){
        //creating a constructor//
         try{
           
           c= DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem","root","0602");
           s= c.createStatement();
           
           
         } catch (Exception e){
             System.out.println(e);
             
         }
        
    
        
    }

    

   

    
    
}
