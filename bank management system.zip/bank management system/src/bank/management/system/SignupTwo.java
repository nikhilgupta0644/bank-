package bank.management.system;

import javax.swing.*;
import java.awt.*;

import java.awt.event.ActionEvent;
import java.awt.event.*;


public class SignupTwo extends JFrame implements ActionListener{
   
long random;
JComboBox religion,category,occupation,education,income;
JRadioButton senioryes,seniorno,existingyes,existingno;
JTextField pan,aadhar;
JButton next;
String formno;



    
    SignupTwo (String formno){
        this.formno=formno;
         
        setLayout(null);
          
        setTitle("NEW ACCOUNT APPLICATION FORM-PAGE 2");
     
        
       JLabel additionaldetails=new JLabel("Page-2:Additional DETAILS");
     additionaldetails.setFont(new Font("Raleway",Font.BOLD,22));
     additionaldetails.setBounds(290,80,400,30);
     add(additionaldetails);
     
     JLabel religion1=new JLabel("Religion:");
     religion1.setFont(new Font("Raleway",Font.BOLD,20));
     religion1.setBounds(100,140,100,30);
     add(religion1);
     
     String valReligion[]={"Hindu","Muslim","Sikh","Christian","Other"};
     religion= new JComboBox(valReligion);
     religion.setBounds(300,140,400,30);
     add(religion);
             
      
     
     
     JLabel category1=new JLabel("Category:");
     category1.setFont(new Font("Raleway",Font.BOLD,20));
     category1.setBounds(100,190,200,30);
     add( category1);
      
     String valcategory[]={"General","OBC","SC","ST","Other"};
     category= new JComboBox(valcategory);
     category.setBounds(300,190,400,30);
     add(category);
     
       
      
     
     JLabel income1=new JLabel("Income:");
     income1.setFont(new Font("Raleway",Font.BOLD,20));
     income1.setBounds(100,240,200,30);
     add(income1);
     
     
     String valincome[]={"Null","<1,50,000","<2,50,000","<5,00,000","Upto 10,00,000"};
      income= new JComboBox(valincome);
       income.setBounds(300,240,400,30);
     add(income);
     
      
     
     JLabel educational=new JLabel("Educational");
     educational.setFont(new Font("Raleway",Font.BOLD,20));
     educational.setBounds(100,290,200,30);
     add(educational);
     
      
         
     JLabel qualifications=new JLabel("Qualifications:");
  qualifications.setFont(new Font("Raleway",Font.BOLD,20));
     qualifications.setBounds(100,315,200,30);
     add(qualifications);
     
      
     String educationvalues[]={"Non Graduation","Graduation","Post-Graduation","Doctrate","Others"};
      education= new JComboBox(educationvalues);
       education.setBounds(300,315,400,30);
     add(education);
    
     
     JLabel occupation1=new JLabel("Occupation:");
     occupation1.setFont(new Font("Raleway",Font.BOLD,20));
     occupation1.setBounds(100,390,200,30);
     add(occupation1);
     
     String occupationvalues[]={"Salaried","Self-Employeed","Bussiness","Student","Retired","Others"};
      occupation= new JComboBox(occupationvalues);
       occupation.setBounds(300,390,400,30);
     add(occupation);
       
     
     
     JLabel pan1=new JLabel("PAN Number:");
     pan1.setFont(new Font("Raleway",Font.BOLD,20));
     pan1.setBounds(100,440,200,30);
     add(pan1);
     
     
       pan =new JTextField();
     pan.setBounds(300,440,400,30);
     add(pan);
     
     
      JLabel aadhar1=new JLabel("Aadhar Number:");
     aadhar1.setFont(new Font("Raleway",Font.BOLD,20));
     aadhar1.setBounds(100,490,200,30);
     add(aadhar1);
      
       aadhar = new JTextField();
     aadhar.setBounds(300,490,400,30);
     add(aadhar);
     
      JLabel senior=new JLabel("Senior Citizen:");
   senior.setFont(new Font("Raleway",Font.BOLD,20));
     senior.setBounds(100,540,200,30);
     add(senior);
     
     
    senioryes=new JRadioButton("Yes");
     senioryes.setBounds(300,540,100,30);
     senioryes.setBackground(Color.PINK);
     add(senioryes);
      seniorno=new JRadioButton("NO");
   seniorno.setBounds(450,540,100,30);
     seniorno.setBackground(Color.PINK);
     add(seniorno);
      
     
      
      ButtonGroup seniorgroup =new ButtonGroup();
    seniorgroup.add(senioryes);
    seniorgroup.add(seniorno);
    
      
      JLabel existingaccount=new JLabel("Existing Account:");
     existingaccount.setFont(new Font("Raleway",Font.BOLD,20));
     existingaccount.setBounds(100,590,200,30);
     add(existingaccount);
     
     existingyes=new JRadioButton("Yes");
     existingyes.setBounds(300,590,100,30);
     existingyes.setBackground(Color.PINK);
     add(existingyes);
      existingno=new JRadioButton("NO");
   existingno.setBounds(450,590,100,30);
     existingno.setBackground(Color.PINK);
     add(existingno);
      
     
      
      ButtonGroup existinggroup=new ButtonGroup();
    existinggroup.add(existingyes);
   existinggroup.add(existingno);
    
     
     
     
     
     
     
       next=new JButton("Next");
     next.setBounds(620,660,80,30);
     next.setBackground(Color.black);
     next.setForeground(Color.pink);
     next.setFont(new Font( "Raleway",Font.BOLD,14));
     next.addActionListener(this);
     add(next);
     
   
      getContentPane().setBackground(Color.WHITE);
         
       setSize(850,800);
    setVisible(true);
     setLocation(350,10);
        
        
        
    }

    SignupTwo() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    public void actionPerformed(ActionEvent ae){
       String formno=""+random; //long
    String sreligion=(String)religion.getSelectedItem();
     String scategory=(String)category.getSelectedItem();
      String sincome=(String)income.getSelectedItem();
       String seducation=(String)education.getSelectedItem();
        String soccupation=(String)occupation.getSelectedItem();
      
      String seniorcitizen=null;
      if(senioryes.isSelected()){
          seniorcitizen="Yes";
      } else if (seniorno.isSelected()){
          seniorcitizen="No";
      }
       
       String existingaccount=null;
        if(existingyes.isSelected()){
          existingaccount="Yes";
      } else if (existingno.isSelected()){
          existingaccount="No";
      }
       
         String pan1=pan.getText();
          String aadhar1=aadhar.getText();
          
       
    try{
        
            Conn c=new Conn();
       
            String query="insert into signuptwo values('"+formno+"','"+sreligion+"', '"+scategory+"', '"+sincome+"','"+seducation+"','"+soccupation+"','"+pan1+"','"+aadhar1+"','"+seniorcitizen+"','"+existingaccount+"')";
        c.s.executeUpdate(query);
        
        //signup3 object
        
       setVisible(false);
       new SignupThree(formno).setVisible(true);
    }catch(Exception e){
        System.out.println(e);
    }
    
}
    
    public static void main (String args[]){
        new SignupTwo("");
    }
    
}
